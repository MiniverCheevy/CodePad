import { useRef, useState, useEffect, FunctionComponent } from 'react';
import * as monaco from 'monaco-editor/esm/vs/editor/editor.api';
import styles from './Editor.module.css';
import './userWorker';
import React from 'react';
//TODO: if instance issue, review https://blog.expo.dev/building-a-code-editor-with-monaco-f84b3a06deaf
export class EditorConfig {
    title?: string;
    show: boolean = true;
}

export const Editor: FunctionComponent<EditorConfig> = (props: EditorConfig) => {
    const showLabel = props.title === null || props.title === undefined;
    const title = props.title;
    const showEditor = props.show ?? true;
    const [editor, setEditor] =
        useState<monaco.editor.IStandaloneCodeEditor | null>(null);
    const [show, setShow] = useState<boolean>(showEditor);
    const monacoEl = useRef(null);
    const style = show ? "block" : "none" //Not rendering the editor breaks it
    useEffect(() => {
        if (monacoEl) {
            setEditor((editor) => {
                if (editor) return editor;

                const editorInstance = monaco.editor.create(monacoEl.current!, {
                    value: ['function x() {', '\tconsole.log("monaco.editor.create");', '}'].join(
                        '\n'
                    ),
                    language: 'typescript',
                    automaticLayout: true,
                });
                const model = editorInstance.getModel();
                if (model) {
                    model.onDidChangeContent = (e: monaco.editor.IModelChangedEvent) => {
                        //debugger;
                    };
                }
            });
        }
        return () => editor?.dispose();
    }, [editor]);
    return (
        <div >
            {
                showLabel && <h5 className="card-title p-0" onClick={() => setShow(!show)}>
                    {title}
                </h5>
            }
            <div id="editor-body" style={{ display: style }} >
                <code className={styles.Editor}>
                    <div className={styles.Editor} ref={monacoEl}></div>
                </code>
            </div>
        </div>
    );
};
